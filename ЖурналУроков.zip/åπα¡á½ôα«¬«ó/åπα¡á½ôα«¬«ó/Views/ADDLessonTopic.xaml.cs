﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ЖурналУроков.Model;

namespace ЖурналУроков.Views
{
    /// <summary>
    /// Логика взаимодействия для ADDLessonTopic.xaml
    /// </summary>
    public partial class ADDLessonTopic : Page
    {
        public ADDLessonTopic()
        {
            InitializeComponent();
            cmbCLass.ItemsSource = AppData.Connection.Class.ToList();
        }

        private void SaveButton(object sender, RoutedEventArgs e)
        {
            LessonTopic topic = new LessonTopic();
            topic.NumberLesson = NumberLesson_tbx.Text;
            topic.TopicLesson = LessonTopic_tbx.Text;
            topic.LessonHour = LessonHour_tbx.Text;

            var CurrentClass = cmbCLass.SelectedItem as Class;
            topic.NumberClass = CurrentClass.ClassNumber;

            AppData.Connection.LessonTopic.Add(topic);
            AppData.Connection.SaveChanges();
            MessageBox.Show("Тема урока была успешно добавлена в базу");
            NavigationService.GoBack();

        }
    }
}
